import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from "./components/home.component";
import Login from "./components/login.component";
import ProductsList from "./components/products-list.component";
import CreateProduct from "./components/create-product.component";
import EditProduct from "./components/edit-product.component";

// step4- Router 
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Clock from './components/clock.component';

function App() {
  return (
    <Router>
      <div className="container">
        <nav className="navbar navbar-expand-lg navbar-dark bg-info">
          <Link to="/" className="navbar-brand">Home</Link>

          <button className="navbar-toggle" type="button"
            data-toggle="collapse"
            data-target="#collapsibleNavbar">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse"
            id="collapsibleNavbar">


            <div className="collpase navbar-collapse">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                  <Link to="/viewProduct" className="nav-link">View Product</Link>
                </li>
                <li className="nav-item">
                  <Link to="/About" className="nav-link">About</Link>
                </li>
                <li className="nav-item">
                  <Link to="/gallery" className="nav-link">Gallery</Link>
                </li>
                <li className="nav-item">
                  <Link to="/contactus" className="nav-link">Contact Us</Link>
                </li>
              </ul>

              {/* login component */}
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link to="/login" className="nav-link text-white">
                    <b>Login</b></Link>
                </li>
              </ul>


            </div>
          </div>
        </nav>
        <br />
        {/* Configuring Route URLs for components */}
        <Route path="/" exact component={Home} />
        <Route path="/home" exact component={Home} />
        <Route path="/viewProduct" exact component={ProductsList} />
        <Route path="/edit/:id" component={EditProduct} />
        <Route path="/login" component={Login} />
        <Route path="/create" component={CreateProduct} />
      <hr/>
      <Clock />
      </div>

    </Router>
  );
}

export default App;
