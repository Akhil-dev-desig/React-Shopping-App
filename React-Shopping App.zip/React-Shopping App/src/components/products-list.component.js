import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import swal from 'sweetalert';
import CreateProduct from './create-product.component';


class Product extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
       
    }

    deleteProduct() {
         let result = window.confirm("Do You Want Delete")
        // let result = (swal({
        //     type: 'success',
        //     title: "Are are sure?",
        //     text: "Once deleted, you will not be able to recover this product",
            
        // })
        //    );
       

        if (result) {

            axios.get("http://localhost:4002/products/delete/" + this.props.product._id)
                .then(console.log('Delelted Successfully'))
                .catch(err => console.log(err));
        } 
         
        window.location.reload(); // fast reloading
         
    }
    render() {
        return (
            <tr>
                <td className={this.props.product.product_completed ? 'completed': ''}> {this.props.product.product_name} </td>
                <td className={this.props.product.product_completed ? 'completed': ''}> {this.props.product.product_cost} </td>
                <td>
                    <Link to={"/edit/" + this.props.product._id}>Edit</Link> &nbsp;&nbsp;
        <button onClick={this.deleteProduct} className="btn btn-link">Delete</button>
                </td>
            </tr >
        )
    }
} // exported from todo-list


export default class ProductsList extends React.Component {

    constructor(props) {
        super(props);
        this.state = { products: [], id: '', product_name: '', product_cost: '' };
        this.componentDidMount();
    } // end of constructor

    componentDidMount() {
        axios.get("http://localhost:4002/products/")
            .then(response => {
                this.setState({ products: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    //iterating over products array map() function is used in React to iterate overe list of items or array of items
    productList() {
        return this.state.products.map(function (currentProduct, i) {
            return <Product product={currentProduct} key={i} />
        })
    }


    render() {
        return (
            <div>
                <div style={{ marginTop: 10 }}>
                    <div className="container">
                        
                        <CreateProduct />

                        <h3> No of Products<span className="badge badge-secondary">{this.state.products.length}</span></h3>
                            <h3>Product List </h3>
                            <table border="1" bgcolor="white" className="table table-striped" style={{ marginTop: 20 }} >
                                <thead bgcolor="orange">
                                    <tr>
                                        <th>Name</th>
                                        <th>Cost</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.productList()}
                                </tbody>
                            </table>
                        

                    </div>
                </div>
            </div>

        );
    }
}

 