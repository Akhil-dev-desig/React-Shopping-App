import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import swal from 'sweetalert';
import ProductsList from './products-list.component';

export default class CreateProduct extends React.Component {

    constructor(props) {
        super(props);

        // binding text box onChange events
        this.onChangeProductName = this.onChangeProductName.bind(this);
        this.onChangeProductCost = this.onChangeProductCost.bind(this);

        // binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);

        this.state = {
            product_name: '',
            product_cost: '',
        }
    } // end of constructor

    onChangeProductName(e) {
        this.setState({
            product_name: e.target.value
        });
    }
    onChangeProductCost(e) {
        this.setState({
            product_cost: e.target.value
        });
    }


    onSubmit(e) {
        e.preventDefault();

        console.log('Form submitted:');
        console.log(`Product Name: ${this.state.product_name}`);
        console.log(`Product Cost: ${this.state.product_cost}`);

        const newProduct = {
            product_name: this.state.product_name,
            product_cost: this.state.product_cost
        };

        // add
        axios.post('http://localhost:4002/products/add', newProduct)
            .then(res => console.log(res.data));

         this.clear();

        // redirecting to Home Component
        // this.props.history.push('/viewProduct');
        window.location.reload();
    } // end of onSubmit() function

    clear() {
        this.setState({
            product_name: '',
            product_cost: ''
        })
    }

    // clearing form fields
    clearForm(e) {
        e.preventDefault();
        this.clear();
    } // end of clearing form fields


    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3 className="text-primary">Manage Products</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Product Name</label>
                        <input type="text" className="form-control"
                            value={this.state.product_name}
                            onChange={this.onChangeProductName} />
                    </div>

                    <div className="form-group">
                        <label>Product Cost</label>
                        <input type="number" className="form-control"
                            value={this.state.product_cost}
                            onChange={this.onChangeProductCost} />
                    </div>

                    <div className="form-group">
                        <input type="submit" value="Create Product"
                            className="btn btn-success" />&nbsp;
                        <button type="button" onClick={this.clearForm}
                            className="btn btn-danger">Clear</button>
                    </div>
                </form>
                 
            </div>
        )
    }
}