import React, { Component } from 'react';

class Clock extends Component {

    constructor() {
        super();
        this.launchClock()
        this.state = {
            currentTime: (new Date()).toLocaleString()
        }
        console.log(this.state)
    }
    launchClock() {
        setInterval(() => {
            console.log('Updating time...')
            this.setState({
                currentTime: (new Date()).toLocaleString()
            })
        }, 1000)
    }
    render() {
        return (
            <div>
                <h4 className="text-right text-info">
                {this.state.currentTime}
                </h4></div>
        );
    }
}

export default Clock;
