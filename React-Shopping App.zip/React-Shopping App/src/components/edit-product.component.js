import React from 'react';
import axios from 'axios';

export default class EditProduct extends React.Component {

    constructor(props) {
        super(props);

        // binding text box onChange events
        this.onChangeProductName = this.onChangeProductName.bind(this);
        this.onChangeProductCost = this.onChangeProductCost.bind(this);

        // binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            product_name: '',
            product_cost: ''
          
        }
    } // end of constructor

    // retrieving data from database and loading in textboxes
    // search todos by id
    componentDidMount() {
        axios.get('http://localhost:4002/products/'
            + this.props.match.params.id)
            .then(response => {
                this.setState({
                    product_name: response.data.product_name,
                    product_cost: response.data.product_cost
                    
                })
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    onChangeProductName(e) {
        this.setState({
            product_name: e.target.value
        });
    }
    onChangeProductCost(e) {
        this.setState({
            product_cost: e.target.value
        });
    } 
    

    onSubmit(e) {
        e.preventDefault();
        const obj = {
            product_name: this.state.product_name,
            product_cost: this.state.product_cost
        };
        console.log(obj);
        // add
        axios.post('http://localhost:4002/products/update/' // instead of put change it to post and add /update/
            + this.props.match.params.id, obj)
            .then(res => console.log(res.data));

        this.props.history.push('/viewProduct');

    } // end of onSubmit() function

    render() {
        return (
            <div>
                <h3 align="center">Update Product</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Product name</label>
                        <input type="text" className="form-control"
                            value={this.state.product_name}
                            onChange={this.onChangeProductName} />
                    </div>

                    <div className="form-group">
                        <label>Product Cost</label>
                        <input type="text" className="form-control"
                            value={this.state.product_cost}
                            onChange={this.onChangeProductCost} />
                    </div>

                    <br />

                    <div className="form-group">
                        <input type="submit" value="Update Product"
                            className="btn btn-primary" />&nbsp;
                    </div>
                </form>
            </div>
        );
    }

}