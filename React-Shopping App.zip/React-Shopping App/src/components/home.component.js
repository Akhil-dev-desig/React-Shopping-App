import React, { Component } from 'react';

function Home() {
    return (
        <div className="row">
            <div className="col-lg-9">
                <h5 className="text-success">Welcome to Online Shopping Page </h5>
                 
            <div className="col-lg-12" align="text-right">
                <img src="images/shop.jpg" className="img-thumbnail" width="300%" height="600%" />
            </div>
        </div>
        </div>
    );
}

export default Home;