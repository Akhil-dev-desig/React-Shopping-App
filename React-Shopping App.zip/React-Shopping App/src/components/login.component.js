import React from 'react';

export default class Login extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: { email: '', password: '' },
            errors: {},
            formIsValid: true
        }
        this.handleChange = this.handleChange.bind(this);
        this.submitLoginForm = this.submitLoginForm.bind(this);
    }

    handleChange(e) {
        let fields = this.state.fields;
        // accessing input values with their names
        // and storing in fields
        fields[e.target.name] = e.target.value;
        this.setState({
            fields: fields
        });
        console.log(this.state.fields);
    }

    submitLoginForm(e) {
      
        e.preventDefault();
        if (this.validateForm()) {
          
            if (this.state.fields.email == "admin@gmail.com"
                && this.state.fields.password == "123456") {
                let fields = {};
                fields["email"] = "";
                fields["password"] = "";
                this.setState({ fields: fields });
                alert("Login Successful");
                this.props.history.push('/viewProduct');
            }
            else {
                alert("Invalid username or password ..!");
            }
        }
    }

    render() {
        return (
            <div className="row">
                <div className="offset-lg-3 col-lg-6">
                    <h3>Login</h3>
                    <form metho="post" name="LoginForm" onSubmit={this.submitLoginForm} >
                        <div className="form-group">
                            <label>Email</label>
                            <input type="text" name="email" className="form-control"
                                value={this.state.fields.email}
                                onChange={this.handleChange} />
                            <div className={this.state.errors.email ? 'alert alert-danger' : ''}>
                            {this.state.errors.email}
                            </div>
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" name="password" className="form-control"
                                value={this.state.fields.password}
                                onChange={this.handleChange} />
                            <div className={this.state.errors.password ? 'alert alert-danger' : ''}>
                            {this.state.errors.password}
                            </div>
                        </div>

                        <div className="form-group">
                            <input type="submit" className="btn btn-success" value="Login" />
                        </div>

                    </form>
                </div>
            </div>
        );
    }

    // Validation for form fields
    validateForm() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;
        console.log(fields);
        if (fields["email"]=="") {
            
            formIsValid = false;
            errors["email"] = "Please enter your Email-ID.";
            console.log(errors);
        }
        else if (typeof fields["email"] !== "undefined") {
            // regular exprssion for email validation
            if (!(fields["email"].match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i))) {
                formIsValid = false;
                errors["email"] = "Please enter Valid Eamil ID";
            }
        }
            else {
                errors["email"] = "";
            }
          
         console.log('1');
            if (!fields["password"]) {
                formIsValid = false;
                errors["password"] = "Please enter your password.";
            }
            else if (typeof fields["password"] !== "undefined") {
                // regular exprssion for password validation
                if (!(fields["password"].length >= 6)) {
                    formIsValid = false;
                    errors["password"] = "Please enter Valid password";
                }
            }
            else {
                errors["password"] = "";
            }
            console.log('2');
            this.setState({
                errors: errors,
                formIsValid: formIsValid
            });
            console.log(this.state.errors, ' ', formIsValid)
            return formIsValid;
        

    }
}