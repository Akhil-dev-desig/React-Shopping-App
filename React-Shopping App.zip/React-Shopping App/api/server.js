const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const productRoutes = require('./routes/productRoutes');
const config = require('./congig/db'); //step2

const PORT = 4002;

mongoose.Prominse = global.Promise; // step3
// let Product = require('./model/product.model');

// step4
mongoose.connect(config.DB, { useNewUrlParser: true}).then(
    () => { console.log('MOngoDB Connection established successfully'); },
    err => { console.log('Cannot connect to datbase' +err.stack);
 }); // end of step4

// const connection = mongoose.connection;

// connection.once('open', function () {
//     console.log("MongoDb Database Connection esatblished Successfully");
// })

 
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/products', productRoutes);

app.listen(PORT, function () {
    console.log("Server is running on Port: " + PORT);
});